package com.rahultamkhane.uber_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
