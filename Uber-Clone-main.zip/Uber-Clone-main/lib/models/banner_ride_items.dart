List rideBannerItems = [
  {
    'title': 'Book Premier',
    'description': 'Export comfort for special days',
    'image': 'assets/images/banner-3.jpg',
  },
  {
    'title': 'Book Auto',
    'description': 'Everyday commute',
    'image': 'assets/images/banner-1.png',
  },
  {
    'title': 'Book Premier',
    'description': 'Export comfort for special days',
    'image': 'assets/images/banner-2.png',
  },
];
