List commuteBannerItems = [
  {
    'title': 'Go with Auto',
    'description': 'Doorstep pick-up, no bargaining',
    'image': 'assets/images/banner-1.png',
  },
  {
    'title': 'Go with Motorbike',
    'description': 'Doorstep pick-up, no bargaining',
    'image': 'assets/images/banner-2.png',
  },
  {
    'title': 'Go with Car',
    'description': 'Doorstep pick-up, no bargaining',
    'image': 'assets/images/banner-3.jpg',
  },
];
