List rideItems = [
  {
    'name': 'Trip',
    'image': 'assets/images/trip.png',
    'hint': 'Promo',
  },
  {
    'name': 'Uber Auto',
    'image': 'assets/images/auto.png',
    'hint': '',
  },
  {
    'name': 'Rentals',
    'image': 'assets/images/rentals.png',
    'hint': '',
  },
  {
    'name': 'Courier',
    'image': 'assets/images/courier.png',
    'hint': '',
  }
];
